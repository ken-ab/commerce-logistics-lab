# 服装订单与跨境履约 · 验证结果

18 个模拟任务 × 3 种策略，共 54 次登记运行。所有失败保留分母，初始状态逐例核对一致。

| 策略 | 任务完成 | 业务成功 | 证据完整 | 约束违规 | 平均费用 CNY | 平均时延 s | P95 s | 平均模型调用 | 委派任务 |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 单 Agent | 12/18 (66.67%) | 72.22% | 72.22% | 0 | 0.03088 | 21.77 | 37.23 | 4.39 | 0 |
| 协调员加专家 | 12/18 (66.67%) | 88.89% | 66.67% | 0 | 0.05040 | 32.32 | 49.38 | 6.50 | 18 |
| 按需委派 | 13/18 (72.22%) | 77.78% | 77.78% | 0 | 0.04331 | 27.97 | 59.05 | 5.50 | 0 |

任务完成同时要求业务正确和指定来源完整。最终展示字段由程序从工具返回中取值；此处不把自由理由中的每句话都视为已校验事实。

## 分业务类型

| 类型 | 单 Agent | 协调员加专家 | 按需委派 |
|---|---:|---:|---:|
| product_info | 2/2; ¥0.0075; 7.6s | 2/2; ¥0.0156; 15.2s | 2/2; ¥0.0168; 16.1s |
| order_ready | 2/2; ¥0.0287; 19.6s | 2/2; ¥0.0341; 24.4s | 2/2; ¥0.0419; 37.5s |
| order_clarification | 2/2; ¥0.0185; 27.2s | 2/2; ¥0.0250; 27.6s | 2/2; ¥0.0187; 19.1s |
| rule_blocked | 2/2; ¥0.0164; 13.1s | 2/2; ¥0.0256; 24.6s | 2/2; ¥0.0277; 21.0s |
| shortage_alternative | 1/2; ¥0.0695; 38.6s | 2/2; ¥0.0489; 26.5s | 2/2; ¥0.0973; 42.8s |
| shipping_normal | 1/2; ¥0.0335; 25.4s | 1/2; ¥0.0832; 47.5s | 2/2; ¥0.0404; 24.9s |
| shipping_infeasible | 1/2; ¥0.0361; 20.4s | 0/2; ¥0.0533; 41.0s | 0/2; ¥0.0383; 24.7s |
| shipping_revision | 0/2; ¥0.0289; 20.6s | 0/2; ¥0.0472; 35.8s | 0/2; ¥0.0533; 26.8s |
| combined | 1/2; ¥0.0387; 23.4s | 1/2; ¥0.1207; 48.4s | 1/2; ¥0.0554; 38.9s |

## 与单 Agent 配对的差异

正的完成率差值有利于比较组；正的费用或时延差值表示代价更高。下列区间按目标 SKU 聚类重采样，仅反映本模拟集合。

| 比较组减单 Agent | 完成率差及 95% 区间 | 平均费用差 CNY | 平均时延差 s |
|---|---:|---:|---:|
| 协调员加专家 | +0.00 pp [-16.67, +16.67] | +0.01953 | +10.55 |
| 按需委派 | +5.56 pp [-11.76, +23.53] | +0.01243 | +6.21 |

## 失败与调用记录

### 单 Agent

调用成功率 100.00%；已知输入/输出 token 270,866/12,747；未返回 usage 的调用 0。引用修正 13 次；被拒工具尝试 4 次。

业务失败：{"selected_variant_source_not_read": 3, "required_order_issue_missing": 1, "wrong_or_nonminimal_candidate": 1, "decision_status_mismatch": 1}

来源缺项：{"ready_order_status_not_cited": 4, "specific_order_issue_not_cited": 1}

### 协调员加专家

调用成功率 100.00%；已知输入/输出 token 425,281/23,622；未返回 usage 的调用 0。引用修正 13 次；被拒工具尝试 2 次。

业务失败：{"decision_status_mismatch": 1, "final_proposal_id_missing_or_stale": 1, "final_route_invalid": 1, "old_proposal_validity_not_observed": 1, "proposal_version_expectation_failed": 1, "selected_variant_source_not_read": 2}

来源缺项：{"adjustment_options_not_cited": 2, "ready_order_status_not_cited": 4, "current_route_arrival_at_not_cited": 2, "current_route_total_cost_cents_not_cited": 1}

### 按需委派

调用成功率 100.00%；已知输入/输出 token 396,741/15,071；未返回 usage 的调用 0。引用修正 15 次；被拒工具尝试 4 次。

业务失败：{"decision_status_mismatch": 2, "selected_variant_source_not_read": 2}

来源缺项：{"adjustment_options_not_cited": 1, "ready_order_status_not_cited": 3}

## 可复核文件与解释范围

[逐例结果 CSV](case_results.csv)；同目录每个 case ID/策略包含原始 `result.json`、初始数据库副本和模型/工具轨迹。`summary.json` 另含逐组费用、时延及全部配对区间。

商品文字来自 Amazon ESCI；款式分组及商家/运输条件为模拟。测试目标 SKU 与验证目标不重合，但目录可共同搜索。案例复用模板且共享目录，不能外推实际商家成功率。

模型 ID/参数固定，不代表上游服务保证不可变权重快照。时延包含网络与服务排队；未测首 token 或真实思考秒数。费用为保守账本估计和预留，非平台发票。

[登记方案](../../../research/APPAREL_EXPERIMENT_PROTOCOL.md) 说明指标、数据分区、冻结与选择规则。
